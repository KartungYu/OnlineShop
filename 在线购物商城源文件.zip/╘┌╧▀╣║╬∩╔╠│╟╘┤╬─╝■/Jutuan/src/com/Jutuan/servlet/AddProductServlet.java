package com.Jutuan.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Jutuan.bean.Product;
import com.Jutuan.service.ProductService;

/**
 * Servlet implementation class AddProductServlet
 * 增加商品servlet
 */
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//获取前端的传过来属性值
		String pname = request.getParameter("pname");
		String market_price = request.getParameter("market_price");
		String shop_price = request.getParameter("shop_price");
		String summary = request.getParameter("summary");
		String characteristics = request.getParameter("characteristics");
		String delivery_time = request.getParameter("delivery_time");
		String pdesc = request.getParameter("pdesc");
		String count = request.getParameter("count");
		String pflag = request.getParameter("pflag");
		String is_new = request.getParameter("is_new");
		//设置商品属性
		Product product = new Product();
		product.setPname(pname);
		product.setMarket_price(Double.parseDouble(market_price));
		product.setShop_price(Double.parseDouble(shop_price));
		product.setSummary(summary);
		product.setDelivery_time(delivery_time);
		product.setPdesc(pdesc);
		product.setCharacteristics(characteristics);
		product.setCount(Integer.parseInt(count));
		product.setIs_new(Integer.parseInt(is_new));
		product.setPflag(Integer.parseInt(pflag));
		try {
			//设置线程sleep 500ms
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		final Object filename = request.getSession().getAttribute("filename");
		if (filename != null) {
			product.setPimage(String.valueOf(filename));
		}else {
			product.setPimage("");
		}

		ProductService pdService = new ProductService();
		pdService.saveProduct(product);
		//添加商品  更新首页商品信息
		ProductService productService = new ProductService();
		List<Product> newList = productService.findBySelected();
		List<Product> yesterdayListPro = productService.findYesterdayProduct();
		
		request.getSession().setAttribute("newList", newList);
		request.getSession().setAttribute("yesterdayListPro", yesterdayListPro);   
		request.setAttribute("msg", "商品添加成功");
		request.getRequestDispatcher("/admin/addpro.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
